// Variables para manejar el carrito
let cartCount = 0;

// Función para mostrar notificación
function showNotification(message) {
    const notification = document.getElementById('notification');
    notification.querySelector('p').textContent = message;
    notification.classList.add('show');

    // Ocultar notificación después de 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Función para actualizar el contador del carrito
function updateCartCount() {
    const cartBadge = document.querySelector('.cart-count');
    cartCount++;
    cartBadge.textContent = cartCount;
    cartBadge.style.display = 'inline';  // Asegurarse de que se vea el contador
}

// Añadir al carrito con notificación creativa
document.querySelectorAll('.snack button, .movie button').forEach(button => {
    button.addEventListener('click', () => {
        // Simula añadir el producto al carrito (en este caso, solo cuenta los productos)
        updateCartCount();

        // Mostrar notificación de éxito
        showNotification('¡Producto añadido al carrito!');
    });
});

