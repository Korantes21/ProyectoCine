document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que el formulario se envíe

    // Obtener los valores de los campos
    const nombre = document.getElementById('nombre').value;
    const tarjeta = document.getElementById('tarjeta').value;
    const caducidad = document.getElementById('caducidad').value;
    const cvv = document.getElementById('cvv').value;

    // Validación simple de que los campos no están vacíos y cumplen los requisitos
    if (nombre && tarjeta.length === 16 && caducidad && cvv.length === 3) {
        // Mostrar mensaje de éxito
        document.getElementById('message').classList.remove('hidden');
        document.getElementById('message').textContent = "¡Pago Exitoso!";
        
        // Limpiar los campos del formulario
        document.getElementById('payment-form').reset();
    } else {
        // Mostrar error si los datos no son correctos
        document.getElementById('message').classList.remove('hidden');
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').textContent = "Error: Datos incorrectos.";
    }
});

document.getElementById('cancelar').addEventListener('click', function() {
    // Limpiar los campos y ocultar el mensaje
    document.getElementById('payment-form').reset();
    document.getElementById('message').classList.add('hidden');
});
